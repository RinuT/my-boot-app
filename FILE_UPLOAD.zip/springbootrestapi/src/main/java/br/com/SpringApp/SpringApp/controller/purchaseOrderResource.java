package br.com.SpringApp.SpringApp.controller;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import br.com.SpringApp.SpringApp.model.purchase;

@RestController

public class purchaseOrderResource {
@RequestMapping("purchase")
	public List<purchase> getPurchase()
	{
		List<purchase> purchase= new ArrayList();
		purchase a1=new purchase();
		a1.setAvailableQuantity("0");
		a1.setCreationDate("0");
		a1.setCurrency("0");
        a1.setDeliveryDate("0");
        a1.setLineNumber("1");
        a1.setManufacturer("0");
        a1.setMaterialCode("0");
        a1.setOrderQuantity("0");
        a1.setOrderStatus("0");
        a1.setPoNumber("0");
        a1.setPrice("0");
        a1.setReceivedQuantity("0");
        a1.setRequiredQuantity("0");
        a1.setShippedQuantity("0");
        a1.setSupplier("0");
        a1.setUop("0");
		return purchase;
	}
@RequestMapping(method=RequestMethod.POST,value="purchase")
	public void addPurchase(@RequestBody String purchase) {
	RestTemplate restTemplate = new RestTemplate();
	String url="http://ec2-35-173-231-185.compute-1.amazonaws.com:3000/api/PlaceOrder";
	//String url="http://p2p-process-network.mybluemix.net/api/PlaceOrder";
	 HttpHeaders headers = new HttpHeaders();
	 headers.setContentType(MediaType.APPLICATION_JSON);
	 purchase=purchase.substring(8, purchase.length()-1);
	//System.out.println(purchase);
	JSONArray output;
	String jsonStringData="";
	try {
		output = new JSONArray(purchase);
		  for (int i = 0; i < output.length(); i++)
		    { 
			  JSONObject po = output.getJSONObject(i);
		      jsonStringData="{\"$class\": \"com.cts.ipm.p2pNetwork.PlaceOrder\",\"poNumber\":\""+ po.getString("PO Number")+"\",\"purchaseorder\": {\"$class\": \"com.cts.ipm.p2pNetwork.newpurchaseorder\",\"lineNumber\": \""+po.getString("Line Number")+"\",\"materialCode\": \""+po.getString("MaterialCode")+"\",\"orderQuantity\":\""+po.getString("PO Qty")+"\",\"shippedQuantity\": \"0\",\"receivedQuantity\": \"0\",\"requiredQuantity\": \"0\",\"availableQuantity\": \"0\",\"uop\": \""+po.getString("UOP")+"\",\"deliveryDate\": \""+po.getString("Delivery Date")+"\",\"creationDate\": \""+po.getString("Creation Date")+"\",\"price\":\""+po.getString("Price")+"\",\"currency\":\""+po.getString("Currency")+"\",\"supplier\":\"Supplier 1\",\"manufacturer\": \"\",\"orderStatus\": \"\",\"batch\": []},\"report\": {\"$class\": \"com.cts.ipm.p2pNetwork.newReport\",\"transactionType\": \"Place Order\",\"date\": \""+po.getString("Creation Date")+"\",\"quantity\": \""+po.getString("PO Qty")+"\",\"poNumber\":\""+ po.getString("PO Number")+"\",\"materialCode\": \""+po.getString("MaterialCode")+"\"}}";  
		      JSONObject request = new JSONObject(jsonStringData);
		      
		      HttpEntity<String> entity = new HttpEntity<String>(jsonStringData,headers);
		      String jsonString = restTemplate.postForObject(url, entity,String.class);
		      //System.out.println(jsonString);
		   
		    }
		  
	} catch (JSONException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

	
	}
}
